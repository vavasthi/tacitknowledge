#include <stdio.h>

int main ()
{
  printf ("Apache Tika!\n");
}
